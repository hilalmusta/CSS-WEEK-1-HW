#Module 1 Lab Activity
#
#To Do:
#At the top of this file:
#Add appropriate comments for your name, date, program description, etc.
#
#For each line of code below:
#   write a comment above it describing what the expression evaluates to and why.
#   You may use the shell to help you and check your work.
#Follow the appropriate style from my examples and the web article
#
#Submit your modified version of this file to d2l by the due date.


#Examples:

#This line evaluates to 90 because subtracting 10 from 100 gives you 90.
100 - 10

#This line evaluates to true because 100 is greater than 10.
100 > 10

#Worth 10 points each:


2+2


12/4


8%2


100*7-4


100*(7-4)


80%(8+9)-7


10 > 7


20 <= 20


20 != 30 and 10 == 7


100 > 98+2 or 7%2 == 1

#BONUS: Modify this code to display the result of each line to the user through the console when this file is run
#       (there are several ways to do this).
